# Copyright (c) 2009-2011 VMware, Inc.
require File.join(File.dirname(__FILE__), '..', 'spec_helper')
