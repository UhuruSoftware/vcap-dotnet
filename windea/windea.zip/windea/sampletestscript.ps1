﻿
$appName = $env:VMC_APP_NAME
$appPort = $enc:VMC_APP_PORT
$appDir = [System.IO.Directory]::GetCurrentDirectory();

$iisCmd = "c:\Windows\System32\inetsrv\appcmd.exe"

$binding = '"http/*:' + $appPort + ':"'
$physicalPath = '"' + $appDir + '"'

& $iisCmd add site /name:$appName$appPort /bindings:$binding /physicalPath:$physicalPath

$process = [System.Diagnostics.Process]::Start("", "..\logs\stdout.log 2>..\logs\stderr.log")

& echo $process::Id >> ..\run.pid

#<%= stop_script_template.lines.map { |l| "echo " + l.strip.inspect + " >> ../stop\n" }.join %>

Wait-Process -Id $process.Id