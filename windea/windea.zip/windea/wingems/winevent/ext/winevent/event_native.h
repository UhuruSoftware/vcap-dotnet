#ifndef EVENT_NATIVE_H
#define EVENT_NATIVE_H

#define ERRMAX 512

#ifndef __cplusplus
// bool rulez
#define bool unsigned char
#define true 1
#define false 0
#endif

typedef enum {
	e_channel_windea = 0,
	e_channel_mssqlnode
}e_channel_t;

typedef enum {
	e_trace_critical = 0,
	e_trace_error,
	e_trace_warning,
	e_trace_informational,
	e_trace_verbose
}e_trace_level_t;

typedef struct _winevent{
	e_channel_t channel_type;
	e_trace_level_t trace_level;
}winevent;

bool 
event_init_lib();

bool 
event_register();

void 
event_unregister();

bool 
event_write(unsigned int channel, unsigned int trace_level, const char *message);

void 
get_error_message( const char *err_buf);


#endif