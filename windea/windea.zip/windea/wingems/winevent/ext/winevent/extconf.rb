require 'mkmf'

dir_config('winevent')

$LIBS << " -ladvapi32"

create_makefile('winevent')
