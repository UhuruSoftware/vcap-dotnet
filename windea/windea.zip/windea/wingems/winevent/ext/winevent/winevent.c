// winevent.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <ruby.h>

#include "event_native.h"

// holds a reference to the exported ruby class
static VALUE rb_cWinEvent; 

// references to classes that are used similar to enums in ruby ( via class constants )
static VALUE rb_eTraceLevel;  
static VALUE rb_eChannelType;

// holds a reference to the exception class exported to ruby
static VALUE rb_exEventException;


// method called by the ruby interpreter when calling <object>.new in ruby
static VALUE winevent_event_initialize(VALUE self)
{
	bool retval = event_init_lib();

	return retval?self:Qnil;
}

static VALUE winevent_event_register(VALUE klass)
{
	bool retval = event_register();

	if( !retval ){
		rb_raise(rb_exEventException, "Event registration failed");
	}

	return Qtrue;
}


static VALUE winevent_event_unregister( VALUE klass )
{
	event_unregister();
	return Qnil;
}

static VALUE winevent_event_write(VALUE klass, VALUE e_channel, VALUE e_level,VALUE payload_str)
{
	ULONG retval = 0L;

	if( !( FIXNUM_P( e_channel ) && FIXNUM_P( e_level ) ) ) { 
		rb_raise(rb_exEventException,"WinEvent::Log(channel,level,message) : the level and channel parameters should be integer values");
		return Qnil;
	}

	if( TYPE( payload_str ) != T_STRING ) { // make sure we have a string passed down
		rb_raise(rb_exEventException, "WinEvent::Log(channel,level,message) : third parameter should be a string");
		return Qnil;
	}

	const char *error_message = StringValueCStr( payload_str );

	int level = FIX2UINT( e_level );
 	int channel = FIX2UINT( e_channel );

	retval = event_write(channel,level,error_message);

	if( !retval ){
		char err_buf[ERRMAX];
		get_error_message(err_buf);
		rb_raise( rb_exEventException,err_buf);
		return Qnil;
	}
	
	return Qtrue;
}

void Init_winevent()
{
	// the Ruby WinEvent class
	rb_cWinEvent = rb_define_class("WinEvent",rb_cObject);

	// define the methods for that class, and associate each with a pointer to a 
	// C function that the interpreter will call
	rb_define_method( rb_cWinEvent,	"initialize",
									winevent_event_initialize, 
									0 );

	rb_define_method(rb_cWinEvent,	"Register",
									winevent_event_register, 
									0 );

	rb_define_method(rb_cWinEvent,	"Unregister",
									winevent_event_unregister, 
									0 );

	rb_define_method(rb_cWinEvent,	"Log",
									winevent_event_write, 
									3 );
	
	// in lack of a better alternative, these classes will map to C enums via their 
	// constants, so for example: in Ruby, instead of eLogChannel::ChannelOperational, 
	// you will use EventChannel::OPERATIONAL
 	rb_eChannelType = rb_define_class( "EventChannel", rb_cObject );
 	
	rb_define_const( rb_eChannelType,	"WINDEA",
										INT2FIX(e_channel_windea));

 	rb_define_const( rb_eChannelType,	"MSSQLNODE", 
										INT2FIX(e_channel_mssqlnode));
  

 	rb_eTraceLevel = rb_define_class("TraceLevel",rb_cObject);

 	rb_define_const(rb_eTraceLevel,	"CRITICAL",	
									INT2FIX(e_trace_critical));

 	rb_define_const(rb_eTraceLevel,	"ERROR",		
									INT2FIX(e_trace_error));

 	rb_define_const(rb_eTraceLevel,	"WARNING",			
									INT2FIX(e_trace_warning));

	rb_define_const(rb_eTraceLevel,	"INFORMATIONAL",		
									INT2FIX(e_trace_informational));

	rb_define_const(rb_eTraceLevel,	"VERBOSE",		
									INT2FIX(e_trace_verbose));

	// define an exception to go with all the above
	rb_exEventException = rb_define_class ( "EventException", rb_eException );

	return;
}

