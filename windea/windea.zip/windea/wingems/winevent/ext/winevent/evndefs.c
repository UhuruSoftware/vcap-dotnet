#include "evndefs.h"

VOID 
EventDataDescCreate(
	PEVENT_DATA_DESCRIPTOR EventDataDescriptor,
	const void* DataPtr,
	unsigned long DataSize
	)
{
	EventDataDescriptor->Ptr = (ULONGLONG)(ULONG_PTR)DataPtr;
	EventDataDescriptor->Size = DataSize;
	EventDataDescriptor->Reserved = 0;
	return;
}
