#include "evndefs.h"
#include "uhurulog.h"

#define EVENT_DESCRIPTORS_COUNT 10

const EVENT_DESCRIPTOR* event_descriptors[ EVENT_DESCRIPTORS_COUNT ] = {
	&WinDEACritical,
	&WinDEAError,
	&WinDEAWarning,
	&WinDEAInformational,
	&WinDEAVerbose,
	&MssqlNodeCritical,
	&MssqlNodeError,
	&MssqlNodeWarning,
	&MssqlNodeInformational,
	&MssqlNodeVerbose
};
