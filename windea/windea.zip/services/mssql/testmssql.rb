require 'dbi'



#db = DBI.connect('DBI:ODBC:rubydemo', 'ruby-demo', 'secret')
db = DBI.connect('DBI:ODBC:Driver={SQL Server Native Client 10.0};Server=W-STEFI;Database=ruby-demo-db;Uid=ruby-demo;Pwd=secret;')

db.disconnect

begin


  db.select_all("select 45")

rescue Exception => e
  puts "#{e}"

end

sql = "
select 34\nINSERT INTO branza (cascaval) VALUES ('gaga')
"
#sql = "DECLARE @sessionId INT\n set @sessionId = 4\n print @sessionId\n "




db.select_all(sql) do |row|
  puts row
end