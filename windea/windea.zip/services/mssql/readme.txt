This folder contains all the ruby code necessary to run a MS SQL Server gateway and node.
These two services provide CloudFoundry the capability to automatically provision SQL Server databases.

Run the mssql_node and mssql_gateway from the services folder, i.e.
  >ruby mssql\bin\mssql_node

