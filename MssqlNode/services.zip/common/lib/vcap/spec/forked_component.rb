require 'vcap/spec/forked_component/base'
require 'vcap/spec/forked_component/nats_server'
