require 'winevent'


class WinLogger

  attr_accessor :eventChannel

  def initialize(channel, logconfig={})
    @eventChannel = channel
    @we = WinEvent.new
    @we.Register

    level = logconfig['level']
    #default logging level
    @loggingLevel = TraceLevel::CRITICAL
    if(level == nil)
      level = "FATAL"
    end

    if(level.casecmp("FATAL") == 0)
      @loggingLevel = TraceLevel::CRITICAL
    end
    if(level.casecmp("ERROR") == 0)
      @loggingLevel = TraceLevel::ERROR
    end
    if(level.casecmp("WARN") == 0)
      @loggingLevel = TraceLevel::WARNING
    end
    if(level.casecmp("INFO") == 0)
      @loggingLevel = TraceLevel::INFORMATIONAL
    end
    if(level.casecmp("DEBUG") == 0)
      @loggingLevel = TraceLevel::VERBOSE
    end
  end

  def Unregister
    @we.Unregister
  end


  def fatal(message)
    if(@loggingLevel >= TraceLevel::CRITICAL)
      @we.Log(@eventChannel, TraceLevel::CRITICAL, message.to_s)
    end
  end

  def error(message)
    if(@loggingLevel >= TraceLevel::ERROR)
      @we.Log(@eventChannel, TraceLevel::ERROR, message.to_s)
    end
  end

  def warn(message)
    if(@loggingLevel >= TraceLevel::WARNING)
      @we.Log(@eventChannel, TraceLevel::WARNING, message.to_s)
    end
  end

  def info(message)
    if(@loggingLevel >= TraceLevel::INFORMATIONAL)
      @we.Log(@eventChannel, TraceLevel::INFORMATIONAL, message.to_s)
    end
  end

  def debug(message)
    if(@loggingLevel >= TraceLevel::VERBOSE)
      @we.Log(@eventChannel, TraceLevel::VERBOSE, message.to_s)
    end
  end


end

