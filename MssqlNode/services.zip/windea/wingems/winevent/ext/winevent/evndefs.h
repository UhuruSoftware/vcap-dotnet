#ifndef EVNDEFS_H
#define EVNDEFS_H

#include <Windows.h>
#include <WinUser.h>

typedef ULONGLONG REGHANDLE, *PREGHANDLE;


#ifndef EVENTAPI
#define EVENTAPI __stdcall
#endif

/*
 Struct definitions taken from the WinSDK Evntprov.h header.
 They describe various Event Provider information used by the 
 event provider API
*/

typedef struct _EVENT_DESCRIPTOR {
	USHORT      Id;
	UCHAR       Version;
	UCHAR       Channel;
	UCHAR       Level;
	UCHAR       Opcode;
	USHORT      Task;
	ULONGLONG   Keyword;

} EVENT_DESCRIPTOR, *PEVENT_DESCRIPTOR;

typedef struct _EVENT_FILTER_DESCRIPTOR {

	ULONGLONG   Ptr;
	ULONG       Size;
	ULONG       Type;

} EVENT_FILTER_DESCRIPTOR, *PEVENT_FILTER_DESCRIPTOR;

typedef struct _EVENT_DATA_DESCRIPTOR {

	ULONGLONG   Ptr;        // Pointer to data
	ULONG       Size;       // Size of data in bytes
	ULONG       Reserved;

} EVENT_DATA_DESCRIPTOR, *PEVENT_DATA_DESCRIPTOR;

VOID 
EventDataDescCreate(
	PEVENT_DATA_DESCRIPTOR EventDataDescriptor,
	const VOID* DataPtr,
	ULONG DataSize
	);

/*
	Function definitions taken from the WinSDK Evntprov.h.
	Used to call the equivalent functions via runtime dynamic linking
	LoadLibrary / GetProcAddress - advapi32.dll
*/

typedef 
VOID
(EVENTAPI *PENABLECALLBACK) (
	LPCGUID SourceId,
	ULONG IsEnabled,
	UCHAR Level,
	ULONGLONG MatchAnyKeyword,
	ULONGLONG MatchAllKeyword,
	PEVENT_FILTER_DESCRIPTOR FilterData,
	PVOID CallbackContext
	);  

typedef 
ULONG 
(EVENTAPI *EventRegister) (
	LPCGUID ProviderId,
	PENABLECALLBACK EnableCallback,
	PVOID CallbackContext,
	PREGHANDLE RegHandle
	);

typedef 
ULONG
(EVENTAPI *EventUnregister) (
	REGHANDLE RegHandle
	);


typedef
ULONG
(EVENTAPI *EventWrite) (
	REGHANDLE RegHandle,
	const EVENT_DESCRIPTOR* EventDescriptor,
	ULONG UserDataCount,
	PEVENT_DATA_DESCRIPTOR UserData
	);

#endif