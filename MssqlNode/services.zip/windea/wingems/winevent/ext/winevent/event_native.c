#include <Windows.h>

#include "event_native.h"
#include "evndefs.h"
#include "uhurulog.h"

#define EVENT_PARAM_COUNT	1
#define MAX_CHANNELS		2
#define MAX_TRACE_LEVEL		5

extern const EVENT_DESCRIPTOR *event_descriptors[MAX_CHANNELS * MAX_TRACE_LEVEL];

static HMODULE		h_event_lib				= (HMODULE)0L;
static REGHANDLE	uhurulog_reg_handle		= (REGHANDLE)0L;

static EventRegister		pfn_event_register		= NULL;
static EventUnregister		pfn_event_unregister	= NULL;
static EventWrite			pfn_event_write			= NULL;

void get_error_message(const char *err_buf)
{
	void *p_msg_buf;

	unsigned long retval		= 0; 
	unsigned long last_error	= GetLastError();

	retval = FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		last_error,
		MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US),
		(char*)&p_msg_buf,
		0,
		NULL
		);

	sprintf(err_buf,"Error code %d : %s",last_error,(char*)p_msg_buf);

	LocalFree( p_msg_buf );
}

bool event_init_lib()
{
	h_event_lib = LoadLibraryA("advapi32.dll");

	if( NULL == h_event_lib ){
		return false;
	}

	pfn_event_register = (EventRegister)GetProcAddress(h_event_lib,"EventRegister");

	if( NULL == pfn_event_register ){
		FreeLibrary( h_event_lib );
		return false;
	}

	pfn_event_unregister = (EventUnregister)GetProcAddress(h_event_lib,"EventUnregister");

	if( NULL == pfn_event_unregister ){
		FreeLibrary( h_event_lib );
		return false;
	}

	pfn_event_write = (EventWrite)GetProcAddress(h_event_lib,"EventWrite");

	if( NULL == pfn_event_write ){
		FreeLibrary( h_event_lib );
		return false;
	}

	return true;
}

bool event_register()
{
	if( uhurulog_reg_handle ){
		return true;
	}

	ULONG retval = pfn_event_register(&uhuru,NULL,NULL,&uhurulog_reg_handle);

	return ( !retval );
}

void event_unregister()
{
	pfn_event_unregister( uhurulog_reg_handle );
}



bool event_write(unsigned int channel, unsigned int trace_level, const char *message)
{
	if( !message || channel >= MAX_CHANNELS || trace_level >= MAX_TRACE_LEVEL ) {
		return false;
	}

	//printf("event_write() --> logging event '%s'\n",message);

	ULONG retval = 0L;

	unsigned int index = channel * MAX_TRACE_LEVEL + trace_level;



	EVENT_DATA_DESCRIPTOR event_data[ EVENT_PARAM_COUNT ];

	//printf("event_write() --> calling EventDataDescCreate()...\n");

	EventDataDescCreate(&event_data[0],(const void*)message,strlen(message)+1);

	//printf("event_write() --> event descriptor index: %d\n",index);
	//printf("event_write() --> event_descriptor[%d] : 0x%X\n",index,event_descriptors[index]);

	retval = pfn_event_write( uhurulog_reg_handle, event_descriptors[ index ], EVENT_PARAM_COUNT, event_data);

	return !retval;
}
