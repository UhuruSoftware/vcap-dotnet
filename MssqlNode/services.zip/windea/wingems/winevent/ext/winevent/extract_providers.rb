require 'rexml/document'
include REXML

file = File.new("uhurulog.man","r")
out_c_file = File.new("event_descriptors.c","w+")

doc = Document.new(file)
root = doc.root
events_root = root.elements["instrumentation"].elements["events"].elements["provider"].elements["events"]

def_event_count = "EVENT_DESCRIPTORS_COUNT"

event_count = events_root.elements.count

out_c_file.write("\#include \"evndefs.h\"\n")
out_c_file.write("\#include \"uhurulog.h\"\n\n")

out_c_file.write("\#define #{def_event_count} #{event_count}\n\n")

out_c_file.write("const EVENT_DESCRIPTOR* event_descriptors[ #{def_event_count} ] = {\n")

i = 0;

events_root.elements.each do | event |
  out_c_file.write("\t&" + event.attributes["symbol"] + ("," if i < 5 ).to_s + "\n" )
  i += 1
end

out_c_file.write("};\n")

file.close()

