require 'winevent'

we = WinEvent.new

we.Register


we.Log(EventChannel::WINDEA, TraceLevel::CRITICAL ,"BLAH... BLAH...")
we.Log(EventChannel::WINDEA, TraceLevel::ERROR ,"BLAH... BLAH...")
we.Log(EventChannel::WINDEA, TraceLevel::WARNING ,"BLAH... BLAH...")
we.Log(EventChannel::WINDEA, TraceLevel::INFORMATIONAL ,"BLAH... BLAH...")
we.Log(EventChannel::WINDEA, TraceLevel::VERBOSE,"BLAH... BLAH...")

we.Log(EventChannel::MSSQLNODE, TraceLevel::CRITICAL,"BLAH... BLAH...")
we.Log(EventChannel::MSSQLNODE, TraceLevel::ERROR,"BLAH... BLAH...")
we.Log(EventChannel::MSSQLNODE, TraceLevel::WARNING,"BLAH... BLAH...")
we.Log(EventChannel::MSSQLNODE, TraceLevel::INFORMATIONAL,"BLAH... BLAH...")
we.Log(EventChannel::MSSQLNODE, TraceLevel::VERBOSE,"BLAH... BLAH...")


we.Unregister
