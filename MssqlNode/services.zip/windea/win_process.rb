require "ChildProcess"
require "tempfile"

module WinProcess
  def self.system(command,  operations, exit_operations)
    Thread.new do
      exitcode, out = copen(command) do |stdout, stderr, stdin, pid|
        operations.call(stdin)
      end

      exit_operations.call(out, exitcode)
    end
  end


  private

  def self.copen(command, &block)
    process = ChildProcess.build(command)

    out = Tempfile.new("inout")
    err = Tempfile.new("err")

    process.io.stdout = out
    process.io.stderr = out

    process.duplex = true
    process.start

    yield process.io.stdout, process.io.stderr, process.io.stdin, process.pid
    block.call(process.io.stdout, process.io.stderr, process.io.stdin, process.pid)

    process.io.stdin.close

    until (ok = process.exited?)
      sleep 0.1
    end

    out.rewind
    outStr = out.read

    return  process.exit_code, outStr
  end
end

#todo: vladi: move this code to a test
#  exec_operation = proc do |process|
#   process.puts "echo test exec operation >> c:\\testem.txt"
#   process.puts "exit 1"
#  end
#
#  exit_operation = proc do |out, status|
#    puts out
#    puts "statusul este #{status}"
#    puts "echo test exit operation is #{status}"
#  end
#
#  sh_command = "cmd"
#
#WinProcess::system(sh_command, exec_operation, exit_operation)


