# Copyright (c) 2009-2011 VMware, Inc.
require 'services/api/async_requests'
require 'services/api/const'
require 'services/api/messages'
require 'services/api/clients/service_gateway_client'
require 'services/api/util'
