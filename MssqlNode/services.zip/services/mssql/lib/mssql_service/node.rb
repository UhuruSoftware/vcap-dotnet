# Copyright (c) 2009-2011 VMware, Inc.
require "erb"
require "fileutils"
require "logger"
require "pp"

require "datamapper"
require "uuidtools"
require "open3"

$LOAD_PATH.unshift File.join(File.dirname(__FILE__), '..', '..', '..', 'base', 'lib')
require 'base/node'
require 'base/service_error'
require 'dbi'

module VCAP
  module Services
    module MsSql
      class Node < VCAP::Services::Base::Node
      end
    end
  end
end

require "mssql_service/common"
require "mssql_service/util"
require "mssql_service/storage_quota"
require "mssql_service/mssql_error"

class VCAP::Services::MsSql::Node

  KEEP_ALIVE_INTERVAL = 15
  LONG_QUERY_INTERVAL = 1
  STORAGE_QUOTA_INTERVAL = 1

  include VCAP::Services::MsSql::Util
  include VCAP::Services::MsSql::Common
  include VCAP::Services::MsSql

  class ProvisionedService
    include DataMapper::Resource
    property :name,       String,   :key => true
    property :user,       String,   :required => true
    property :password,   String,   :required => true
    property :plan,       Enum[:free], :required => true
    property :quota_exceeded,  Boolean, :default => false
  end

  def initialize(options)
    super(options)

    @mssql_config = options[:mssql]

    @max_db_size = options[:max_db_size] * 1024 * 1024
    @max_long_query = options[:max_long_query]
    @max_long_tx = options[:max_long_tx]
    @mssqldump_bin = options[:mssqldump_bin]
    @gzip_bin = options[:gzip_bin]
    @mssql_bin = options[:mssql_bin]

    @connection = mssql_connect

    EM.add_periodic_timer(KEEP_ALIVE_INTERVAL) {mssql_keep_alive}
    EM.add_periodic_timer(@max_long_query.to_f/2) {kill_long_queries} if @max_long_query > 0
    EM.add_periodic_timer(@max_long_tx.to_f/2) {kill_long_transaction} if @max_long_tx > 0
    EM.add_periodic_timer(STORAGE_QUOTA_INTERVAL) {enforce_storage_quota}


    @base_dir = options[:base_dir]
    FileUtils.mkdir_p(@base_dir) if @base_dir

    DataMapper.setup(:default, options[:local_db])
    DataMapper::auto_upgrade!

    check_db_consistency()

    @available_storage = options[:available_storage] * 1024 * 1024
    @node_capacity = @available_storage
    ProvisionedService.all.each do |provisioned_service|
      @available_storage -= storage_for_service(provisioned_service)
    end


    @queries_served=0
    @qps_last_updated=0
    # initialize qps counter
    get_qps
    @long_queries_killed=0
    @long_tx_killed=0
    @provision_served=0
    @binding_served=0
  end

  def announcement
    a = {
      :available_storage => @available_storage
    }
    a
  end

  def check_db_consistency()
    # method present in mysql and postgresql
    #todo: vladi: this should be replaced with ms sql server code
  end

  def storage_for_service(provisioned_service)
    case provisioned_service.plan
    when :free then @max_db_size
    else
      raise MsSqlError.new(MsSqlError::MSSQL_INVALID_PLAN, provisioned_service.plan)
    end
  end

  def mssql_connect
    host, user, password, port, socket =  %w{host user pass port socket}.map { |opt| @mssql_config[opt] }

    5.times do
      begin
        return DBI.connect("DBI:ODBC:#{host}")
      rescue => e
        @logger.info("MSSQL connection attempt failed: [#{e}]")
        sleep(5)
      end
    end

    @logger.fatal("MSSQL connection unrecoverable")
    shutdown
    exit
  end

  #keep connection alive, and check db liveness
  def mssql_keep_alive
    #present in both mysql and postgresql

    @connection.select_all("select CURRENT_TIMESTAMP")
  rescue Exception => e
    @logger.warn("MsSql connection lost: #{e}")
    @connection = msql_connect
  end

  def kill_long_queries
    #present in both mysql and postgresql
    #todo: vladi: Replace with code for odbc object for SQL Server

  end

  def kill_long_transaction
    #present in both mysql and postgresql
    #todo: vladi: Replace with code for odbc object for SQL Server

  end

  def provision(plan, credential=nil)
    provisioned_service = ProvisionedService.new
    if credential
      name, user, password = %w(name user password).map{|key| credential[key]}
      provisioned_service.name = name
      provisioned_service.user = user
      provisioned_service.password = password
    else
      # mssql database name should start with alphabet character
      provisioned_service.name = 'D4TA' + UUIDTools::UUID.random_create.to_s.gsub(/-/, '')
      provisioned_service.user = 'US3R' + generate_credential
      provisioned_service.password = 'P4SS' + generate_credential
    end
    provisioned_service.plan = plan

    create_database(provisioned_service)

    if not provisioned_service.save
      @logger.error("Could not save entry: #{provisioned_service.errors.pretty_inspect}")
      raise MsSqlError.new(MsSqlError::MSSQL_LOCAL_DB_ERROR)
    end
    response = gen_credential(provisioned_service.name, provisioned_service.user, provisioned_service.password)
    @provision_served += 1
    return response
  rescue => e
    delete_database(provisioned_service)
    raise e
  end

  def unprovision(name, credentials)
    return if name.nil?
    @logger.debug("Unprovision database:#{name}, bindings: #{credentials.inspect}")
    provisioned_service = ProvisionedService.get(name)
    raise MsSqlError.new(MsSqlError::MSSQL_CONFIG_NOT_FOUND, name) if provisioned_service.nil?
    # TODO: validate that database files are not lingering
    # Delete all bindings, ignore not_found error since we are unprovision
    begin
      credentials.each{ |credential| unbind(credential)} if credentials
    rescue =>e
      # ignore
    end
    delete_database(provisioned_service)
    storage = storage_for_service(provisioned_service)
    @available_storage += storage
    if not provisioned_service.destroy
      @logger.error("Could not delete service: #{provisioned_service.errors.pretty_inspect}")
      raise MsSqlError.new(MsSqlError::MSSQL_LOCAL_DB_ERROR)
    end
    @logger.debug("Successfully fulfilled unprovision request: #{name}")
    true
  end

  def bind(name, bind_opts, credential=nil)
    @logger.debug("Bind service for db:#{name}, bind_opts = #{bind_opts}")
    binding = nil
    begin
      service = ProvisionedService.get(name)
      raise MsSqlError.new(MsSqlError::MSSQL_CONFIG_NOT_FOUND, name) unless service
      # create new credential for binding
      binding = Hash.new
      if credential
        binding[:user] = credential["user"]
        binding[:password ]= credential["password"]
      else
        binding[:user] = 'US3R' + generate_credential
        binding[:password ]= 'P4SS' + generate_credential
      end
      binding[:bind_opts] = bind_opts
      create_database_user(name, binding[:user], binding[:password])
      response = gen_credential(name, binding[:user], binding[:password])
      @logger.debug("Bind response: #{response.inspect}")
      @binding_served += 1
      return response
    rescue => e
      delete_database_user(binding[:user]) if binding
      raise e
    end
  end

  def unbind(credential)
    return if credential.nil?
    @logger.debug("Unbind service: #{credential.inspect}")
    name, user, bind_opts,passwd = %w(name user bind_opts password).map{|k| credential[k]}
    service = ProvisionedService.get(name)
    raise MsSqlError.new(MsSqlError::MSSQL_CONFIG_NOT_FOUND, name) unless service
    # validate the existence of credential, in case we delete a normal account because of a malformed credential
    #res = @connection.select_all("SELECT * from mssql.user WHERE user='#{user}' AND password=PASSWORD('#{passwd}')")
    #raise MsSqlError.new(MsSqlError::MSSQL_CRED_NOT_FOUND, credential.inspect) if res.num_rows()<=0
    delete_database_user(user)
    true
  end

  def create_database(provisioned_service)
    name, password, user = [:name, :password, :user].map { |field| provisioned_service.send(field) }
    begin
      start = Time.now
      @logger.debug("Creating: #{provisioned_service.pretty_inspect}")
      @connection.select_all("CREATE DATABASE #{name}")
      create_database_user(name, user, password)
      storage = storage_for_service(provisioned_service)
      raise MsSqlError.new(MsSqlError::MSSQL_DISK_FULL) if @available_storage < storage
      @available_storage -= storage
      @logger.debug("Done creating #{provisioned_service.pretty_inspect}. Took #{Time.now - start}.")
    rescue => e
      @logger.warn("Could not create database: [#{e.message}]")
    end
  end

  def create_database_user(name, user, password)
      @logger.info("Creating credentials: #{user}/#{password} for database #{name}")
      @connection.select_all("
        USE master
        CREATE LOGIN #{user} WITH PASSWORD = '#{password}'

        USE #{name}
        CREATE USER #{user} FOR LOGIN #{user}
        EXEC sp_addrolemember N'db_owner', N'#{user}'

      ")
  end

  def delete_database(provisioned_service)
    name, user = [:name, :user].map { |field| provisioned_service.send(field) }
    begin
      delete_database_user(user)
      @logger.info("Deleting database: #{name}")
      @connection.select_all("
        ALTER DATABASE #{name} SET OFFLINE WITH ROLLBACK IMMEDIATE
        DROP DATABASE #{name}
      ")
    rescue => e
      @logger.fatal("Could not delete database: [#{e.message}]")
    end
  end

  def delete_database_user(user)
    @logger.info("Delete user #{user}")
    kill_user_session(user)
    @connection.select_all("
      DROP USER #{user}
      USE master
      DROP LOGIN #{user}
    ")
  rescue => e
    @logger.fatal("Could not delete user '#{user}': [#{e.message}]")
  end

  # end active sesions for USER, to be able to drop the table
  def kill_user_session(user)

    @connection.select_all("
      DECLARE @loginNameToDrop sysname
      SET @loginNameToDrop = '#{user}';

      DECLARE sessionsToKill CURSOR FAST_FORWARD FOR
        SELECT session_id
        FROM sys.dm_exec_sessions
        WHERE login_name = @loginNameToDrop
      OPEN sessionsToKill

      DECLARE @sessionId INT
      DECLARE @statement NVARCHAR(200)

      FETCH NEXT FROM sessionsToKill INTO @sessionId

      WHILE @@FETCH_STATUS = 0
      BEGIN
        PRINT 'Killing session ' + CAST(@sessionId AS NVARCHAR(20)) + ' for login ' + @loginNameToDrop

        SET @statement = 'KILL ' + CAST(@sessionId AS NVARCHAR(20))
        EXEC sp_executesql @statement

        FETCH NEXT FROM sessionsToKill INTO @sessionId
      END

      CLOSE sessionsToKill
      DEALLOCATE sessionsToKill
    ");

  end

  def kill_database_session(database)
    #todo: vladi: Replace with code for odbc object for SQL Server
  end

  # restore a given instance using backup file.
  def restore(name, backup_path)
    #todo: vladi: Replace with code for odbc object for SQL Server
  end

  # Disable all credentials and kill user sessions
  def disable_instance(prov_cred, binding_creds)
    #todo: vladi: Replace with code for odbc object for SQL Server
  end

  # Dump db content into given path
  def dump_instance(prov_cred, binding_creds, dump_file_path)
    #todo: vladi: Replace with code for odbc object for SQL Server
  end

  # Provision and import dump files
  # Refer to #dump_instance
  def import_instance(prov_cred, binding_creds, dump_file_path, plan)
    #todo: vladi: Replace with code for odbc object for SQL Server
  end

  # Re-bind credentials
  # Refer to #disable_instance
  def enable_instance(prov_cred, binding_creds_hash)
    #todo: vladi: Replace with code for odbc object for SQL Server
  end

  # shell CMD wrapper and logger
  def exe_cmd(cmd, stdin=nil)
    @logger.debug("Execute shell cmd:[#{cmd}]")
    o, e, s = Open3.capture3(cmd, :stdin_data => stdin)
    if s.exitstatus == 0
      @logger.info("Execute cmd:[#{cmd}] successd.")
    else
      @logger.error("Execute cmd:[#{cmd}] failed. Stdin:[#{stdin}], stdout: [#{o}], stderr:[#{e}]")
    end
    return [o, e, s]
  end

  def varz_details()
    @logger.debug("Generate varz.")
    varz = {}
    # how many queries served since startup
    varz[:queries_since_startup] = get_queries_status
    # queries per second
    varz[:queries_per_second] = get_qps
    # disk usage per instance
    status = get_instance_status
    varz[:database_status] = status
    # node capacity
    varz[:node_storage_capacity] = @node_capacity
    varz[:node_storage_used] = @node_capacity - @available_storage
    # how many long queries and long txs are killed.
    varz[:long_queries_killed] = @long_queries_killed
    varz[:long_transactions_killed] = @long_tx_killed
    # how many provision/binding operations since startup.
    varz[:provision_served] = @provision_served
    varz[:binding_served] = @binding_served
    varz
  rescue => e
    @logger.error("Error during generate varz: #{e}")
    {}
  end

  def healthz_details()
    #todo: vladi: Replace with code for odbc object for SQL Server
    healthz = {:self => "ok"}
    healthz
  end

  def get_instance_healthz(instance)
    #todo: vladi: Replace with code for odbc object for SQL Server
    res = "ok"
    res
  end

  def get_queries_status()
    #todo: vladi: Replace with code for odbc object for SQL Server
    return 0
  end

  def get_qps()
    @logger.debug("Calculate queries per seconds.")
    queries = get_queries_status
    ts = Time.now.to_i
    delta_t = (ts - @qps_last_updated).to_f
    qps = (queries - @queries_served)/delta_t
    @queries_served = queries
    @qps_last_updated = ts
    qps
  end

  def get_instance_status()
    #todo: vladi: Replace with code for odbc object for SQL Server
    result = []
    result
  end

  def gen_credential(name, user, passwd)
    response = {
      "name" => name,
      "hostname" => @local_ip,
      "host" => @local_ip,
      "port" => @mssql_config['port'],
      "user" => user,
      "username" => user,
      "password" => passwd,
    }
  end
end