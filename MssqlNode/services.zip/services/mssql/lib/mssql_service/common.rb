# Copyright (c) 2009-2011 VMware, Inc.
module VCAP
  module Services
    module MsSql
      module Common
        def service_name
          "MssqlaaS"
        end
      end
    end
  end
end
