require 'dbi'

db = DBI.connect('DBI:ODBC:vladi-server-dsn', 'sa', 'Freed0m')

sql = "SELECT * FROM table1"

db.select_all(sql) do |row|
  puts row
end
