If the pages in the chm file are not displaying correctly, try the following:
- save the chm file somewhere on your PC
- right click on the chm file, then go to properties
- at the bottom of the window, you will find an "unlock" button; click it, then apply your changes
- you should be able to see the contents of the chm file